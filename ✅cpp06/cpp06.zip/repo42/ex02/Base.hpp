#pragma once

class Base {
	public:
		virtual ~Base( void ) {};
};
